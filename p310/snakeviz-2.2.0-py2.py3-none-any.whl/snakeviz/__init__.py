from .ipymagic import *

VERSION = version = __version__ = '2.2.0'
