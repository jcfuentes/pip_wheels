shiboken_library_soversion = str(5.15)

version = "5.15.2.1"
version_info = (5, 15, 2.1, "", "")

__build_date__ = '2022-01-07T13:13:47+00:00'




__setup_py_package_version__ = '5.15.2.1'
