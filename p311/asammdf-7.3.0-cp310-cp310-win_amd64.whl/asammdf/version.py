# -*- coding: utf-8 -*-
""" asammdf version module """

__version__ = "7.3.0"
