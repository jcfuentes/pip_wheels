class TunaError(Exception):
    pass
