# for python -m tuna
from .cli import main

main()
